package com.example.login_register_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
